require 'test_helper'

class HomesControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
